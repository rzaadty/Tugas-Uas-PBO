<footer>
	<div class="footer clearfix mb-0 text-muted">




	</div>
</footer>
</div>
</div>
<script src="<?php echo base_url('path/dist/assets/static/js/components/dark.js'); ?>"></script>
<script src="<?php echo base_url('path/dist/assets/extensions/perfect-scrollbar/perfect-scrollbar.min.js'); ?>"></script>
<script src="<?php echo base_url('path/dist/assets/compiled/js/app.js'); ?>"></script>
<script src="<?php echo base_url('path/dist/assets/extensions/simple-datatables/umd/simple-datatables.js'); ?>"></script>
<script src="<?php echo base_url('path/dist/assets/static/js/pages/simple-datatables.js'); ?>"></script>
</body>
</html>
