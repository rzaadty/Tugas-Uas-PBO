

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>DASHBOARD CUSTOMER</title>


	<link rel="shortcut icon" href="<?php echo base_url('path/gambar_tampilan/logo.png'); ?>"
		type="image/x-icon">

	<link rel="stylesheet" href="<?php echo base_url('path/dist/assets/compiled/css/app.css'); ?>">
	<link rel="stylesheet" href="<?php echo base_url('path/dist/assets/compiled/css/app-dark.css'); ?>">
	<link rel="stylesheet" href="<?php echo base_url('path/dist/assets/extensions/simple-datatables/style.css'); ?>">
	<link rel="stylesheet" href="<?php echo base_url('path/dist/assets/compiled/css/table-datatable.css'); ?>">
	
</head>
<body>
	<script src="<?php echo base_url('path/dist/assets/static/js/initTheme.js'); ?>"></script>
